import pandas as pd
import numpy as np
import random
import os
import csv

# get test and train file
# app_train_read = pd.read_csv('./First_week/application_train.csv')  # read original date
# app_train_read = pd.DataFrame(app_train_read)
# test_buffer = []
# new_train = []
# date = []
# header = list(app_train_read.columns)
# for i in range(0,200000):
#     test_buffer.append(random.randint(0, len(app_train_read)))
# set_test_buffer=list(set(test_buffer))
# set_test_buffer.sort()
# print(set_test_buffer)
# print(len(set_test_buffer))
# for i in range(len(set_test_buffer)):
# 	if i in set_test_buffer:
# 		date
# for j in range(len(set_test_buffer)):
# 	app_train = pd.DataFrame.append({header[j]:})
#
# # submission = pd.DataFrame({'SK_ID_CURR': test_ids, 'TARGET': test_predictions})
#
# app_train_read = pd.read_csv('../Data/application_train.csv')  # read original date
# app_train_read = pd.DataFrame(app_train_read)
# print(app_train_read.shape)
# test_date  = app_train_read[:50000][:]
# train_date  = app_train_read[50000:][:]
# print(test_date)
# print(train_date)
# test_date.to_csv("test_date2.csv",index=0,header=1)
# train_date.to_csv("train_date2.csv",index=0,header=1)
# # read file
# app_test_read = pd.read_csv('test_date2.csv')  # read original date
# print(app_test_read.shape)
# print(app_test_read)
# app_train_read = pd.read_csv('train_date2.csv')  # read original date
# print(app_train_read.shape)
# print(app_train_read)

from sklearn.model_selection import  train_test_split
app_train_read = pd.read_csv('../Data/application_train.csv')  # read original date

X = app_train_read.drop(columns=['TARGET'])  # test set drop columns TARGET

y = app_train_read['TARGET']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3,random_state=42)

print(X_train.shape)
print(y_train.shape)
X_train_copy = X_train.copy()
X_train_copy['TARGET'] = y_train
X_train_copy.index = range(len(X_train_copy))
print(X_train_copy.shape)

X_test_copy = X_test.copy()
X_test_copy['TARGET'] = y_test
X_test_copy.index = range(len(X_test_copy))
print(X_test_copy.shape)

X_train_copy.to_csv('../Data/train_data1.csv',index=0,header=1)
X_test_copy.to_csv('../Data/test_data1.csv',index=0,header=1)