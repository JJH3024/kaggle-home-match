# numpy and pandas for data manipulation
import numpy as np
import pandas as pd
import os
from texttable import Texttable
import warnings
warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score
import  types
app_train_read = pd.read_csv('./First_week/application_train.csv')  # read original date
header = app_train_read.columns
select = []
# print(header)
# for i in header:
#     date_buffer=app_train_read[i]
#     print(date_buffer.describe())
# print("dtypes of train set:")
# print(app_train_read.dtypes.value_counts())
# print("unique object of train set:")
for i in header:
	if app_train_read[i].nunique()<=2:
		# print(app_train_read[i].describe())
		select.append(i)
# buffer = app_train_read.select_dtypes('int').apply(pd.Series.nunique, axis=0)  # 参数axis为0表示按列查找 1为按行
select.remove('TARGET')
select.remove('NAME_CONTRACT_TYPE')
select.remove('FLAG_OWN_CAR')
select.remove('FLAG_OWN_REALTY')
temp_y0 = []
temp_y1 = []
for i in select:
		temp_y1.append(np.sum(app_train_read[i] == 1))
		temp_y0.append(np.sum(app_train_read[i] == 0))

date = pd.DataFrame({'0': temp_y0, '1':temp_y1,'feature':select})
print(date)