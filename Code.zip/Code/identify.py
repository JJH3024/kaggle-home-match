# numpy and pandas for data manipulation
import pandas as pd
import warnings
warnings.filterwarnings('ignore')
import numpy as np
from sklearn import metrics
import matplotlib.pyplot as plt
from sklearn.metrics import auc


predit = pd.read_csv('../Result/baseline_lgb.csv')  # 读取预测结果

print("predit dateshape:")
print(predit.shape)
predit_id = predit['SK_ID_CURR']
predit_label = predit['TARGET']

app_test = pd.read_csv('../Data/test_data1.csv')    # 读取原始测试数据
print("test data shape:")
print(app_test.shape)
lables = app_test['TARGET']

test_y = np.array(lables)
y_scores = np.array(predit_label)

test_auc = metrics.roc_auc_score(test_y,y_scores)  # ROC曲线计算auc
print("auc : %s"%test_auc)

# precision, recall, _thresholds = metrics.precision_recall_curve(test_y,y_scores)   # pr曲线计算AUC
# area = metrics.auc(recall, precision)
# print("area : %s"%area)
#
# fpr, tpr, thresholds = metrics.roc_curve(test_y,y_scores,pos_label=1)
# print("fpr : %s"%fpr)
# print("fpr : %s"%tpr)
# print("thresholds : %s"%thresholds)
# auc = auc(fpr, tpr)
# print("auc : %s "% auc)
#
#
#
# plt.title("PR")
# plt.xlabel('Recall')
# plt.ylabel('Precision')
# plt.plot(precision,recall , '-',label="pr")
# plt.legend()
# plt.show()
#
#
# plt.title("ROC")
# plt.xlabel('False Positive Rate')
# plt.ylabel('True Positive Rata')
# plt.plot(fpr,tpr , '-',label="roc")
# plt.legend()
# plt.show()
