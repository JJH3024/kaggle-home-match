import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import os
from texttable import Texttable
import warnings
warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import KFold
from sklearn.metrics import roc_auc_score
import lightgbm as lgb
import gc
from sklearn.preprocessing import Imputer
import random
print_key = False
def main():

    # app_train_read = pd.read_csv('./First_week/application_train.csv')  # read original date
    # # app_train = pd.read_csv('./First_week/application_train.csv')
    # # app_test = pd.read_csv('./First_week/application_test.csv')
    # app_test = app_train_read[:40000][:]    # test set
    # app_train = app_train_read[40000:][:]   # train set

    app_test = pd.read_csv('../Data/test_data1.csv')  # read original date
    app_train = pd.read_csv('../Data/train_data1.csv')  # read original date


    # app_train.to_csv("app_train.csv", index=False)   # save as csv
    # app_test.to_csv('app_test.csv', index=False)

    app_test = app_test.drop(columns=['TARGET'])  # test set drop columns TARGET

    # 1.查看数据的行列
    dateshape(app_train, app_test)

    # 2.统计标签数据
    statistic_col(app_train)

    # 3.计算数据缺失率
    print("missing values of train set:")
    missing_values = missing_values_table(app_train)  # Missing values statistics
    print(missing_values.head(20))  # Print some summary information

    # 4.查看各特征数据类型
    print("dtypes of train set:")
    print(app_train.dtypes.value_counts())

    # 5.查看对象分类中唯一条目的数量
    print("unique object of train set:")
    print(app_train.select_dtypes('object').apply(pd.Series.nunique, axis=0))  # 参数axis为0表示按列查找 1为按行

    # 6. lable编码
    app_train, app_test = LabelEncoding(app_train, app_test)

    # 7.One-Hot编码
    app_train, app_test = OneHotEncoding(app_train, app_test)

    # 8. 调整训练和培训数据一致
    app_train, app_test = AligningDate(app_train, app_test)

    # 9.EDA 异常数据分析处理
    app_train, app_test = EDA_anom(app_train, app_test)

    # 10.EDA pearson系统统计,计算各特征之间的pearson系数
    app_train, app_test = EDAPearson(app_train, app_test)

    # 11.EDA_Feature
    app_train, app_test = EDA_Feature(app_train, app_test)

    # 12.创建新特征
    app_train_ploy, app_test_ploy = CreateNewFeature(app_train, app_test)

    # 13.发现新特征  创建新特征 CREDIT_INCOME_PERCENT，ANNUITY_INCOME_PERCENT，CREDIT_TERM，DAYS_EMPLOYED_PERCENT
    app_train_domain, app_test_domain = FindFeature(app_train, app_test)

    # 14.EDALogistic物流回归实施
    feature_importances, feature_importances_domain =  EDALogistic(app_train, app_test, app_train_ploy, app_test_ploy, app_train_domain, app_test_domain)

    # 15.查看特征重要性
    # Show the feature importances for the default features
    # feature_importances_sorted = plot_feature_importances(feature_importances)
    # feature_importances_domain_sorted = plot_feature_importances(feature_importances_domain)

    # 16. Gradient Boosting Machine
    # submission, fi, metrics = model(app_train, app_test)
    # print('Baseline metrics')
    # print(metrics)
    # fi_sorted = plot_feature_importances(fi)
    # submission.to_csv('baseline_lgb2.csv', index=False)


    # # Test the domain knolwedge features
    # app_train_domain['TARGET'] = app_train['TARGET']
    # submission_domain, fi_domain, metrics_domain = model(app_train_domain, app_test_domain)
    # print('Baseline with domain knowledge features metrics')
    # print(metrics_domain)
    # fi_sorted = plot_feature_importances(fi_domain)
    # submission_domain.to_csv('baseline_lgb_domain_features1.csv', index=False)


def model(features, test_features, encoding='ohe', n_folds=5):

    # Extract the ids
    train_ids = features['SK_ID_CURR']
    test_ids = test_features['SK_ID_CURR']

    # Extract the labels for training
    labels = features['TARGET']

    # Remove the ids and target
    features = features.drop(columns=['SK_ID_CURR', 'TARGET'])
    test_features = test_features.drop(columns=['SK_ID_CURR'])

    # One Hot Encoding
    if encoding == 'ohe':
        features = pd.get_dummies(features)
        test_features = pd.get_dummies(test_features)

        # Align the dataframes by the columns
        features, test_features = features.align(test_features, join='inner', axis=1)

        # No categorical indices to record
        cat_indices = 'auto'

    # Integer label encoding
    elif encoding == 'le':

        # Create a label encoder
        label_encoder = LabelEncoder()

        # List for storing categorical indices
        cat_indices = []

        # Iterate through each column
        for i, col in enumerate(features):
            if features[col].dtype == 'object':
                # Map the categorical features to integers
                features[col] = label_encoder.fit_transform(np.array(features[col].astype(str)).reshape((-1,)))
                test_features[col] = label_encoder.transform(np.array(test_features[col].astype(str)).reshape((-1,)))

                # Record the categorical indices
                cat_indices.append(i)

    # Catch error if label encoding scheme is not valid
    else:
        raise ValueError("Encoding must be either 'ohe' or 'le'")

    print('model Training Data Shape: ', features.shape)
    print('model Testing Data Shape: ', test_features.shape)

    # Extract feature names
    feature_names = list(features.columns)

    # Convert to np arrays
    features = np.array(features)
    test_features = np.array(test_features)
    # Create the kfold object
    k_fold = KFold(n_splits=n_folds, shuffle=True, random_state=50)

    # Empty array for feature importances
    feature_importance_values = np.zeros(len(feature_names)) # len:239

    # Empty array for test predictions
    test_predictions = np.zeros(test_features.shape[0])  # len:48744

    # Empty array for out of fold validation predictions
    out_of_fold = np.zeros(features.shape[0])   # len:307511

    # Lists for recording validation and training scores
    valid_scores = []
    train_scores = []

    # Iterate through each fold
    for train_indices, valid_indices in k_fold.split(features):
        # Training data for the fold
        train_features, train_labels = features[train_indices], labels[train_indices]
        print('train_features')
        print(train_features)
        print('labels')
        print(train_labels)
        # Validation data for the fold
        valid_features, valid_labels = features[valid_indices], labels[valid_indices]

        # Create the model
        model = lgb.LGBMClassifier(n_estimators=10000, objective='binary',
                                   class_weight='balanced', learning_rate=0.05,
                                   reg_alpha=0.1, reg_lambda=0.1,
                                   subsample=0.8, n_jobs=-1, random_state=50)

        # Train the model
        model.fit(train_features, train_labels, eval_metric='auc',
                  eval_set=[(valid_features, valid_labels), (train_features, train_labels)],
                  eval_names=['valid', 'train'], categorical_feature=cat_indices,
                  early_stopping_rounds=100, verbose=200)

        # Record the best iteration
        best_iteration = model.best_iteration_

        # Record the feature importances
        feature_importance_values += model.feature_importances_ / k_fold.n_splits

        # Make predictions
        test_predictions += model.predict_proba(test_features, num_iteration=best_iteration)[:, 1] / k_fold.n_splits

        # Record the out of fold predictions
        out_of_fold[valid_indices] = model.predict_proba(valid_features, num_iteration=best_iteration)[:, 1]

        # Record the best score
        valid_score = model.best_score_['valid']['auc']
        train_score = model.best_score_['train']['auc']

        valid_scores.append(valid_score)
        train_scores.append(train_score)

        # Clean up memory
        gc.enable()
        del model, train_features, valid_features
        gc.collect()

    # Make the submission dataframe
    submission = pd.DataFrame({'SK_ID_CURR': test_ids, 'TARGET': test_predictions})

    # Make the feature importance dataframe
    feature_importances = pd.DataFrame({'feature': feature_names, 'importance': feature_importance_values})

    # Overall validation score
    valid_auc = roc_auc_score(labels, out_of_fold)

    # Add the overall scores to the metrics
    valid_scores.append(valid_auc)
    train_scores.append(np.mean(train_scores))

    # Needed for creating dataframe of validation scores
    fold_names = list(range(n_folds))
    fold_names.append('overall')

    # Dataframe of validation scores
    metrics = pd.DataFrame({'fold': fold_names,
                            'train': train_scores,
                            'valid': valid_scores})

    return submission, feature_importances, metrics

def EDA_anom(app_train, app_test):
    print('DateaAnalyze:\n')
    print(" feature DAYS_BIRTH:")
    # train表    1.发现DAYS_BIRTH 异常为负数  2.DAYS_EMPLOYED异常
    print("DAYS_BIRTH describe:")
    print((app_train['DAYS_BIRTH']).describe())
    print("DAYS_BIRTH/-365 describe:")
    print((app_train['DAYS_BIRTH'] / -365).describe())
    print("DAYS_EMPLOYED describe:")
    print(app_train['DAYS_EMPLOYED'].describe())
    app_train['DAYS_EMPLOYED'].plot.hist(title='Days Employment Histogram')
    plt.xlabel('Days Employment')
    if print_key is True:
        plt.show()

    # DAYS_EMPLOYED特征异常数据分析
    print(" feature DAYS_EMPLOYED")
    anom = app_train[app_train['DAYS_EMPLOYED'] == 365243]
    non_anom = app_train[app_train['DAYS_EMPLOYED'] != 365243]
    print('The non-anomalies default on %0.2f%% of loans' % (100 * non_anom['TARGET'].mean()))
    print('The anomalies default on %0.2f%% of loans' % (100 * anom['TARGET'].mean()))
    print('There are %d anomalous days of employment' % len(anom))

    # DAYS_EMPLOYED特征异常数据处理
    # Create an anomalous flag column
    app_train['DAYS_EMPLOYED_ANOM'] = app_train["DAYS_EMPLOYED"] == 365243
    # Replace the anomalous values with nan
    app_train['DAYS_EMPLOYED'].replace({365243: np.nan}, inplace=True)
    # print(app_train['DAYS_EMPLOYED'])

    app_train['DAYS_EMPLOYED'].plot.hist(title='Days Employment Histogram');
    plt.xlabel('Days Employment')
    if print_key is True:
        plt.show()

    # test表同样对DAYS_EMPLOYED数据进行异常处理
    app_test['DAYS_EMPLOYED_ANOM'] = app_test["DAYS_EMPLOYED"] == 365243
    app_test["DAYS_EMPLOYED"].replace({365243: np.nan}, inplace=True)

    print('There are %d anomalies in the test data out of %d entries' % (
    app_test["DAYS_EMPLOYED_ANOM"].sum(), len(app_test)))

    app_test['DAYS_EMPLOYED'].plot.hist(title='Days Employment Histogram');
    plt.xlabel('Days Employment')
    if print_key is True:
        plt.show()

    return app_train, app_test

def CreateNewFeature(app_train, app_test):
    # Make a new dataframe for polynomial features
    print("CreateNewFeature:")
    poly_features = app_train[['EXT_SOURCE_1', 'EXT_SOURCE_2', 'EXT_SOURCE_3', 'DAYS_BIRTH', 'TARGET']]
    poly_features_test = app_test[['EXT_SOURCE_1', 'EXT_SOURCE_2', 'EXT_SOURCE_3', 'DAYS_BIRTH']]

    # imputer for handling missing values
    imputer = Imputer(strategy='median')   # 弥补缺失值 用中位数进行替换  mean：用平均值进行替换  ，most_frequent :用众数进行替换

    poly_target = poly_features['TARGET']

    poly_features = poly_features.drop(columns=['TARGET'])

    # Need to impute missing values
    poly_features = imputer.fit_transform(poly_features)   # transform in same standard
    poly_features_test = imputer.transform(poly_features_test)
    print('Imputer Features shape: ', poly_features.shape)
    print('Imputer Features_test shape: ', poly_features_test.shape)

    # Create the polynomial object with specified degree
    from sklearn.preprocessing import PolynomialFeatures
    poly_transformer = PolynomialFeatures(degree=3)  # create new feature with  Polynomial

    # Train the polynomial features
    poly_transformer.fit(poly_features)

    # Transform the features
    poly_features = poly_transformer.transform(poly_features)
    poly_features_test = poly_transformer.transform(poly_features_test)
    print('Polynomial Features shape: ', poly_features.shape)
    print('Polynomial Features_test shape: ', poly_features_test.shape)

    feature_name = poly_transformer.get_feature_names(input_features=['EXT_SOURCE_1', 'EXT_SOURCE_2', 'EXT_SOURCE_3', 'DAYS_BIRTH'])[
    :15]
    print("afert Polynomial feature name :")
    print(feature_name)

    # 查看新特征与标签的关联性
    # Create a dataframe of the features
    poly_features = pd.DataFrame(poly_features,
                                 columns=poly_transformer.get_feature_names(['EXT_SOURCE_1', 'EXT_SOURCE_2',
                                                                             'EXT_SOURCE_3', 'DAYS_BIRTH']))
    # Add in the target
    poly_features['TARGET'] = poly_target
    # Find the correlations with the target
    poly_corrs = poly_features.corr()['TARGET'].sort_values()
    # Display most negative and most positive
    print("Train set after Polynomial, corr with TARGET :")
    print(poly_corrs.head(10))
    print(poly_corrs.tail(5))

    # Put test features into dataframe
    poly_features_test = pd.DataFrame(poly_features_test,
                                      columns=poly_transformer.get_feature_names(['EXT_SOURCE_1', 'EXT_SOURCE_2',
                                                                                  'EXT_SOURCE_3', 'DAYS_BIRTH']))

    # Merge polynomial features into training dataframe
    poly_features['SK_ID_CURR'] = app_train['SK_ID_CURR']
    app_train_poly = app_train.merge(poly_features, on='SK_ID_CURR', how='left')

    # Merge polnomial features into testing dataframe
    poly_features_test['SK_ID_CURR'] = app_test['SK_ID_CURR']
    app_test_poly = app_test.merge(poly_features_test, on='SK_ID_CURR', how='left')

    # Align the dataframes
    app_train_poly, app_test_poly = app_train_poly.align(app_test_poly, join='inner', axis=1)

    # Print out the new shapes
    print('Training data with polynomial features shape: ', app_train_poly.shape)
    print('Testing data with polynomial features shape:  ', app_test_poly.shape)

    return app_train_poly, app_test_poly

def EDALogistic(app_train, app_test,app_train_poly, app_test_poly, app_train_domain, app_test_domain):

    print("EDALogistic:")
    print(app_train.shape)
    from sklearn.preprocessing import MinMaxScaler, Imputer
    # Drop the target from the training data
    if 'TARGET' in app_train:                               # 去掉TARGET列
        train = app_train.drop(columns=['TARGET'])
    else:
        train = app_train.copy()

    # Feature name
    features = list(train.columns)                          # 取特征列

    # Copy of the testing data
    test = app_test.copy()

    # Median imputation of missing values
    imputer = Imputer(strategy='median')  # 弥补缺失值 用中位数进行替换  mean：用平均值进行替换  ，most_frequent :用众数进行替换

    # Scale each feature to 0-1
    scaler = MinMaxScaler(feature_range=(0, 1))  #数据归一化处理，归一到0-1区间上
    # Fit on the training data
    imputer.fit(train)

    # Transform both training and testing data
    train = imputer.transform(train)
    test = imputer.transform(app_test)

    # Repeat with the scaler
    scaler.fit(train)
    train = scaler.transform(train)
    test = scaler.transform(test)

    print('EDALogistic Training data shape: ', train.shape)
    print('EDALogistic Testing data shape: ', test.shape)
    train_labels = app_train['TARGET']

    # # LogisticRegression
    from sklearn.linear_model import LogisticRegression
    # # Make the model with the specified regularization parameter
    log_reg = LogisticRegression(C=0.0001)

    # Train on the training data

    log_reg.fit(train, train_labels)   # 训练模型

    # Make predictions
    # Make sure to select the second column only
    log_reg_pred = log_reg.predict_proba(test)[:, 1]
    print("LogisticRegression predict result:")
    print(log_reg_pred)

    # Submission dataframe
    submit = app_test[['SK_ID_CURR']]
    submit['TARGET'] = log_reg_pred
    submit.head()
    print(submit)
    # Save the submission to a csv file
    submit.to_csv('../Result/log_reg_baseline.csv', index=False)

    # 随机森林模型
    # from sklearn.ensemble import RandomForestClassifier
    #
    # # Make the random forest classifier
    # random_forest = RandomForestClassifier(n_estimators=100, random_state=50, verbose=1, n_jobs=-1)
    # # Train on the training data
    # random_forest.fit(train, train_labels)
    #
    # # Extract feature importances
    # feature_importance_values = random_forest.feature_importances_
    # feature_importances = pd.DataFrame({'feature': features, 'importance': feature_importance_values})
    #
    # # Make predictions on the test data
    # predictions = random_forest.predict_proba(test)[:, 1]
    # print(predictions)
    # # Make a submission dataframe
    # submit = app_test[['SK_ID_CURR']]
    # submit['TARGET'] = predictions
    # # Save the submission dataframe
    # submit.to_csv('random_forest_baseline2.csv', index=False)

    # # Testing Poly Features
    # poly_features_names = list(app_train_poly.columns)
    #
    # # Impute the polynomial features
    # from sklearn.ensemble import RandomForestClassifier
    # imputer = Imputer(strategy='median')
    #
    # poly_features = imputer.fit_transform(app_train_poly)
    # poly_features_test = imputer.transform(app_test_poly)
    #
    # # Scale the polynomial features
    # scaler = MinMaxScaler(feature_range=(0, 1))
    #
    # poly_features = scaler.fit_transform(poly_features)
    # poly_features_test = scaler.transform(poly_features_test)
    #
    # random_forest_poly = RandomForestClassifier(n_estimators=100, random_state=50, verbose=1, n_jobs=-1)
    # # Train on the training data
    # random_forest_poly.fit(poly_features, train_labels)
    #
    # # Make predictions on the test data
    # predictions = random_forest_poly.predict_proba(poly_features_test)[:, 1]
    #
    # # Make a submission dataframe
    # submit = app_test[['SK_ID_CURR']]
    # submit['TARGET'] = predictions
    # # Save the submission dataframe
    # submit.to_csv('random_forest_baseline_engineered.csv', index=False)

    # # Testing Domain Features
    # app_train_domain = app_train_domain.drop(columns='TARGET')
    # domain_features_names = list(app_train_domain.columns)
    #
    # # Impute the domainnomial features
    # imputer = Imputer(strategy='median')
    # from sklearn.ensemble import RandomForestClassifier
    # domain_features = imputer.fit_transform(app_train_domain)
    # domain_features_test = imputer.transform(app_test_domain)
    #
    # # Scale the domainnomial features
    # scaler = MinMaxScaler(feature_range=(0, 1))
    #
    # domain_features = scaler.fit_transform(domain_features)
    # domain_features_test = scaler.transform(domain_features_test)
    #
    # random_forest_domain = RandomForestClassifier(n_estimators=100, random_state=50, verbose=1, n_jobs=-1)
    #
    # random_forest_domain.fit(domain_features, train_labels)
    #
    # # Extract feature importances
    # feature_importance_values_domain = random_forest_domain.feature_importances_
    # feature_importances_domain = pd.DataFrame(
    #     {'feature': domain_features_names, 'importance': feature_importance_values_domain})
    #
    # # Make predictions on the test data
    # predictions = random_forest_domain.predict_proba(domain_features_test)[:, 1]
    # # Make a submission dataframe
    # submit = app_test[['SK_ID_CURR']]
    # submit['TARGET'] = predictions
    # print(submit)
    # # Save the submission dataframe
    # submit.to_csv('random_forest_baseline_domain.csv', index=False)

    # return feature_importances, feature_importances_domain
    return feature_importances

def plot_feature_importances(df):
    # Sort features according to importance
    df = df.sort_values('importance', ascending=False).reset_index()

    # Normalize the feature importances to add up to one
    df['importance_normalized'] = df['importance'] / df['importance'].sum()

    # Make a horizontal bar chart of feature importances
    plt.figure(figsize=(10, 6))
    ax = plt.subplot()

    # Need to reverse the index to plot most important on top
    ax.barh(list(reversed(list(df.index[:15]))),
            df['importance_normalized'].head(15),
            align='center', edgecolor='k')

    # Set the yticks and labels
    ax.set_yticks(list(reversed(list(df.index[:15]))))
    ax.set_yticklabels(df['feature'].head(15))

    # Plot labeling
    plt.xlabel('Normalized Importance');
    plt.title('Feature Importances')
    plt.show()

    return df

def FindFeature(app_train, app_test):  # 创建新特征 CREDIT_INCOME_PERCENT，ANNUITY_INCOME_PERCENT，CREDIT_TERM，DAYS_EMPLOYED_PERCENT
    app_train_domain = app_train.copy()
    app_test_domain = app_test.copy()

    app_train_domain['CREDIT_INCOME_PERCENT'] = app_train_domain['AMT_CREDIT'] / app_train_domain['AMT_INCOME_TOTAL']
    app_train_domain['ANNUITY_INCOME_PERCENT'] = app_train_domain['AMT_ANNUITY'] / app_train_domain['AMT_INCOME_TOTAL']
    app_train_domain['CREDIT_TERM'] = app_train_domain['AMT_ANNUITY'] / app_train_domain['AMT_CREDIT']
    app_train_domain['DAYS_EMPLOYED_PERCENT'] = app_train_domain['DAYS_EMPLOYED'] / app_train_domain['DAYS_BIRTH']

    app_test_domain['CREDIT_INCOME_PERCENT'] = app_test_domain['AMT_CREDIT'] / app_test_domain['AMT_INCOME_TOTAL']
    app_test_domain['ANNUITY_INCOME_PERCENT'] = app_test_domain['AMT_ANNUITY'] / app_test_domain['AMT_INCOME_TOTAL']
    app_test_domain['CREDIT_TERM'] = app_test_domain['AMT_ANNUITY'] / app_test_domain['AMT_CREDIT']
    app_test_domain['DAYS_EMPLOYED_PERCENT'] = app_test_domain['DAYS_EMPLOYED'] / app_test_domain['DAYS_BIRTH']

    plt.figure(figsize=(12, 20))
    # iterate through the new features
    # for i, feature in enumerate(
    #         ['CREDIT_INCOME_PERCENT', 'ANNUITY_INCOME_PERCENT', 'CREDIT_TERM', 'DAYS_EMPLOYED_PERCENT']):
    #     # create a new subplot for each source
    #     plt.subplot(4, 1, i + 1)
    #     # plot repaid loans
    #     sns.kdeplot(app_train_domain.loc[app_train_domain['TARGET'] == 0, feature], label='target == 0')
    #     # plot loans that were not repaid
    #     sns.kdeplot(app_train_domain.loc[app_train_domain['TARGET'] == 1, feature], label='target == 1')
    #
    #     # Label the plots
    #     plt.title('Distribution of %s by Target Value' % feature)
    #     plt.xlabel('%s' % feature);
    #     plt.ylabel('Density')
    #     plt.show()
    # plt.tight_layout(h_pad=2.5)

    return app_train_domain, app_test_domain

def EDAPearson(app_train, app_test):       # pearson系数分析各特征与偿还贷款能力的相关性 1.年龄
    print("feature pearson top 15 and tail 15:")
    # Find correlations with the target and sort
    correlations = app_train.corr()['TARGET'].sort_values()

    # Display correlations
    print('Most Positive Correlations:\n', correlations.tail(15))
    print('Most Negative Correlations:\n', correlations.head(15))
    return app_train, app_test

# 对DAYS_BIRTH EXT_SOURCE特征的分析
def EDA_Feature(app_train, app_test):
    # Find the correlation of the positive days since birth and target
    app_train['DAYS_BIRTH'] = abs(app_train['DAYS_BIRTH'])
    correlations_abs = app_train['DAYS_BIRTH'].corr(app_train['TARGET'])
    print("corr of DAYS_BIRTH and TARGET:")
    print(correlations_abs)

    # 画年龄段分布图
    # Set the style of plots
    plt.style.use('fivethirtyeight')
    # Plot the distribution of ages in years
    plt.hist(app_train['DAYS_BIRTH'] / 365, edgecolor='k', bins=25)
    plt.title('Age of Client');
    plt.xlabel('Age (years)');
    plt.ylabel('Count');
    if print_key is True:
        plt.show()

    # 画年龄与标签相关度图
    plt.figure(figsize = (10, 8))
    # KDE plot of loans that were repaid on time
    sns.kdeplot(app_train.loc[app_train['TARGET'] == 0, 'DAYS_BIRTH'] / 365, label = 'target == 0')
    # KDE plot of loans which were not repaid on time
    sns.kdeplot(app_train.loc[app_train['TARGET'] == 1, 'DAYS_BIRTH'] / 365, label = 'target == 1')
    # Labeling of plot
    plt.xlabel('Age (years)'); plt.ylabel('Density'); plt.title('Distribution of Ages');

    # 查看年龄与标签的相关度
    # ge information into a separate dataframe
    age_data = app_train[['TARGET', 'DAYS_BIRTH']]
    age_data['YEARS_BIRTH'] = age_data['DAYS_BIRTH'] / 365
    # Bin the age data
    age_data['YEARS_BINNED'] = pd.cut(age_data['YEARS_BIRTH'], bins=np.linspace(20, 70, num=10,endpoint = False))
    print(age_data.head(10))

    # Group by the bin and calculate averages
    age_groups = age_data.groupby('YEARS_BINNED').mean()
    print(age_groups)

    # 画年龄段与标签相关度图
    plt.figure(figsize=(8, 8))
    # Graph the age bins and the average of the target as a bar plot
    plt.bar(age_groups.index.astype(str), 100 * age_groups['TARGET'])
    # Plot labeling
    plt.xticks(rotation=75);
    plt.xlabel('Age Group (years)');
    plt.ylabel('Failure to Repay (%)')
    plt.title('Failure to Repay by Age Group');
    if print_key is True:
        plt.show()


    # 对EXT_SOURCE_1，EXT_SOURCE_2，EXT_SOURCE_3，DAYS_BIRTH特征的分析
    ext_data = app_train[['TARGET', 'EXT_SOURCE_1', 'EXT_SOURCE_2', 'EXT_SOURCE_3', 'DAYS_BIRTH']]
    ext_data_corrs = ext_data.corr()
    print("corr of TARGET EXT_SOURCE_1 EXT_SOURCE_2 EXT_SOURCE_3 DAYS_BIRTH")
    print(ext_data_corrs)

    # 画标签与EXT_SOURCE_1，EXT_SOURCE_2，EXT_SOURCE_3，DAYS_BIRTH的相关度图
    plt.figure(figsize=(8, 6))
    # Heatmap of correlations
    sns.heatmap(ext_data_corrs, cmap=plt.cm.RdYlBu_r, vmin=-0.25, annot=True, vmax=0.6)
    plt.title('Correlation Heatmap')
    if print_key is True:
        plt.show()

    # plt.figure(figsize=(10, 12))
    # # iterate through the sources
    # for i, source in enumerate(['EXT_SOURCE_1', 'EXT_SOURCE_2', 'EXT_SOURCE_3']):
    #     # create a new subplot for each source
    #     plt.subplot(3, 1, i + 1)
    #     # plot repaid loans
    #     sns.kdeplot(app_train.loc[app_train['TARGET'] == 0, source], label='target == 0')
    #     # plot loans that were not repaid
    #     sns.kdeplot(app_train.loc[app_train['TARGET'] == 1, source], label='target == 1')
    #
    #     # Label the plots
    #     plt.title('Distribution of %s by Target Value' % source)
    #     plt.xlabel('%s' % source);
    #     plt.ylabel('Density');
    #     if print_key is True:
    #       plt.show()
    #
    # plt.tight_layout(h_pad=2.5)

    # Copy the data for plotting
    plot_data = ext_data.drop(columns=['DAYS_BIRTH']).copy()
    # Add in the age of the client in years
    plot_data['YEARS_BIRTH'] = age_data['YEARS_BIRTH']
    # Drop na values and limit to first 100000 rows
    plot_data = plot_data.dropna().loc[:100000, :]

    # Function to calculate correlation coefficient between two columns
    def corr_func(x, y, **kwargs):
        r = np.corrcoef(x, y)[0][1]
        ax = plt.gca()
        ax.annotate("r = {:.2f}".format(r),
                    xy=(.2, .8), xycoords=ax.transAxes,
                    size=20)
    # Create the pairgrid object
    grid = sns.PairGrid(data=plot_data, size=3, diag_sharey=False,
                        hue='TARGET',
                        vars=[x for x in list(plot_data.columns) if x != 'TARGET'])
    # Upper is a scatter plot
    grid.map_upper(plt.scatter, alpha=0.2)
    # Diagonal is a histogram
    grid.map_diag(sns.kdeplot)
    # Bottom is density plot
    grid.map_lower(sns.kdeplot, cmap=plt.cm.OrRd_r);
    plt.suptitle('Ext Source and Age Features Pairs Plot', size=32, y=1.05);
    if print_key is True:
        plt.show()

    return app_train, app_test


def dateshape(app_train, app_test):     # 打印数据表形状
    # Training data
    # statistic_col()

    # Testing data features
    print('Train data shape: ', app_train.shape)
    app_train.head()

    print('Testing data shape: ', app_test.shape)
    app_test.head()

def statistic_col(app_train):
    print("TARGET percent of train set:")
    print(app_train['TARGET'].value_counts())
    app_train['TARGET'].astype(int).plot.hist()
    if print_key is True:
        plt.show()


# Function to calculate missing values by column# Funct
def missing_values_table(df):
    # Total missing values
    mis_val = df.isnull().sum()

    # Percentage of missing values
    mis_val_percent = 100 * df.isnull().sum() / len(df)

    # Make a table with the results
    mis_val_table = pd.concat([mis_val, mis_val_percent], axis=1)  # mis_val，mis_val_percent数据合并成一行
    # Rename the columns
    mis_val_table_ren_columns = mis_val_table.rename(     # 设置列名
        columns={0: 'Missing Values', 1: '% of Total Values'})

    # Sort the table by percentage of missing descending
    mis_val_table_ren_columns = mis_val_table_ren_columns[
        mis_val_table_ren_columns.iloc[:, 1] != 0].sort_values(
        '% of Total Values', ascending=False).round(1)   # 降序排序数据 保留一位小数
    print("Your selected dataframe has " + str(df.shape[1]) + " columns.\n"   # 打印df的列数
                                                              "There are " + str(mis_val_table_ren_columns.shape[0]) +
          " columns that have missing values.")   #打印df的行数

    # Return the dataframe with missing information
    return mis_val_table_ren_columns

# 标签编码
def LabelEncoding(app_train, app_test):  # label编码
    print("label encoding:")
    # Create a label encoder object
    le = LabelEncoder()
    le_count = 0

    # Iterate through the columns
    for col in app_train:
        if app_train[col].dtype == 'object':
            # If 2 or fewer unique categories
            if len(list(app_train[col].unique())) <= 2:
                # Train on the training data
                le.fit(app_train[col])
                # Transform both training and testing data
                app_train[col] = le.transform(app_train[col])
                app_test[col] = le.transform(app_test[col])

                # Keep track of how many columns were label encoded
                le_count += 1

    print('%d columns were label encoded.' % le_count)
    print('Training Features shape: ', app_train.shape)
    print('Testing Features shape: ', app_test.shape)
    return  app_train, app_test

def OneHotEncoding(app_train, app_test):   # one-hot编码
    print("one-hot encoding:")
    app_train = pd.get_dummies(app_train)
    app_test = pd.get_dummies(app_test)

    print('Training Features shape: ', app_train.shape)
    print('Testing Features shape: ', app_test.shape)

    return app_train, app_test

def AligningDate(app_train, app_test):
    print('Aliging Date:')
    train_labels = app_train['TARGET']

    # Align the training and testing data, keep only columns present in both dataframes
    app_train, app_test = app_train.align(app_test, join='inner', axis=1)  # 内连接app_train 和 app_test

    # Add the target back in
    app_train['TARGET'] = train_labels

    print('Training Features shape: ', app_train.shape)
    print('Testing Features shape: ', app_test.shape)
    return app_train, app_test

if __name__ == '__main__':
        main()