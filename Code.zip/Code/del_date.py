#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import csv
import pandas as pd
from pandas import DataFrame


def main():
    # del_datecol_train()
    # del_datecol_test()
    # DelDate_PreviousApplication()

    # application_train_del = pd.read_csv('./First_week/application_train_del.csv')  # 读取训练数据
    # header1 = application_train_del.columns
    # print(header1)
    # application_train = pd.read_csv('./First_week/application_train.csv')  # 读取训练数据
    # header2 = application_train.columns
    # print(header2)

    # application_test_del = pd.read_csv('./First_week/application_test_del.csv')  # 读取训练数据
    # header1 = application_test_del.columns
    # print(header1)
    # application_test_del = pd.read_csv('./First_week/application_test.csv')  # 读取训练数据
    # header2 = application_test_del.columns
    # print(header2)

    application_test_del = pd.read_csv('./First_week/previous_application.csv')  # 读取训练数据
    header1 = application_test_del.columns
    print(header1)
    application_test_del = pd.read_csv('./First_week/previous_application_del.csv')  # 读取训练数据
    header2 = application_test_del.columns
    print(header2)



def del_datecol_train(): # 删除application_train|test.csv中的数据
    buffer = []
    application_train = pd.read_csv('./First_week/application_train.csv')  # 读取训练数据
    buffer = pd.DataFrame(application_train);
    header = buffer.columns
    del_list = ('FLAG_MOBIL', 'FLAG_DOCUMENT_2', 'FLAG_DOCUMENT_4', 'FLAG_DOCUMENT_7', 'FLAG_DOCUMENT_10', 'FLAG_DOCUMENT_12', 'FLAG_DOCUMENT_15', 'FLAG_DOCUMENT_17', 'FLAG_DOCUMENT_21')
    for col in header:
        if col in del_list:
            del buffer[col]
    buffer.to_csv("./First_week/application_train_del.csv", index=0)

def del_datecol_test(): # 删除application_train|test.csv中的数据
    buffer = []
    application_test = pd.read_csv('./First_week/application_test.csv')  # 读取训练数据
    buffer = pd.DataFrame(application_test);
    header = buffer.columns
    del_list = ('FLAG_MOBIL', 'FLAG_DOCUMENT_2', 'FLAG_DOCUMENT_4', 'FLAG_DOCUMENT_7', 'FLAG_DOCUMENT_10', 'FLAG_DOCUMENT_12', 'FLAG_DOCUMENT_15', 'FLAG_DOCUMENT_17', 'FLAG_DOCUMENT_21')
    for col in header:
        if col in del_list:
            del buffer[col]
    buffer.to_csv("./First_week/application_test_del.csv", index=0)

def DelDate_PreviousApplication(): # 删除application_train|test.csv中的数据
    buffer = []
    previous_application = pd.read_csv('./First_week/previous_application.csv')  # 读取训练数据
    buffer = pd.DataFrame(previous_application);
    header = buffer.columns
    del_list = ('RATE_INTEREST_PRIMARY', 'RATE_INTEREST_PRIVILEGED')
    for col in header:
        if col in del_list:
            del buffer[col]
    buffer.to_csv("./First_week/previous_application_del.csv", index=0)

if __name__ == '__main__':
     main()