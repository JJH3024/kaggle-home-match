#!/usr/bin/python
# -*- coding: UTF-8 -*-
import random
import os
import csv
import math
import pandas as pd
import numpy as np
from pandas import DataFrame


def main():
    application_train = pd.read_csv('./First_week/application_train_del.csv')  # 读取训练数据
    df = pd.DataFrame(application_train)
    # df.info()
    vector1 = df['YEARS_BUILD_MODE'] # Name: AMT_GOODS_PRICE, Length: 307511, dtype: float64
    vector2 = df['YEARS_BUILD_AVG']      # Name: AMT_CREDIT, Length: 307511, dtype: float64
    # print(len(df["AMT_GOODS_PRICE"][pd.isnull(df["AMT_GOODS_PRICE"])]) / len(df))
    # print(len(df["AMT_CREDIT"][pd.isnull(df["AMT_CREDIT"])]) / len(df))
    # print(df[pd.isnull(df['AMT_GOODS_PRICE'])])  # 打印COMMONAREA_MEDI列为null的数据
    # print(df[pd.isnull(df['AMT_CREDIT'])])  # 打印COMMONAREA_MEDI列为null的数据
    # print(vector1)
    # print(vector2)
    # l = list(zip(vector1, vector2))
    # for i in l:
    #     print(i)
    print(pearson(vector1, vector2))



def pearson(vector1, vector2):                        # 计算pearson系数函数
    n = len(vector1)
    #simple sums
    sum1 = sum(float(vector1[i]) for i in range(n))  # 将vector中的元素转换成float类型进行计算求和
    print("sum1")
    print(sum1)
    sum2 = sum(float(vector2[i]) for i in range(n))
    print("sum2")
    print(sum2)
    #sum up the squares
    sum1_pow = sum([pow(v, 2.0) for v in vector1])   # 求vector中元素的平方和
    print("sum1_pow")
    print(sum1_pow)
    sum2_pow = sum([pow(v, 2.0) for v in vector2])
    print("sum2_pow")
    print(sum2_pow)
    #sum up the products
    p_sum = sum([vector1[i]*vector2[i] for i in range(n)])  # 求vector1 和 vector2元素乘机之和
    print("p_sum")
    print(p_sum)
    #分子num，分母den
    num = p_sum - (sum1*sum2/n)
    print("num")
    print(num)
    den = math.sqrt((sum1_pow-pow(sum1, 2)/n)*(sum2_pow-pow(sum2, 2)/n))
    if den == 0:
        return 0.0
    return num/den

if __name__ == '__main__':
     main()

