import time
import numpy
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

seed = 7
numpy.random.seed(seed)  # 初始化随机数生成器

def main():
    # if 'TARGET' in train_data:  # 去掉TARGET列
    #     train = train_data.drop(columns=['TARGET'])
    # else:
    #     train = train_data.copy()

    train_data = pd.read_csv("../Data/train_data1.csv")  # 加载数据集
    test_data = pd.read_csv("../Data/test_data1.csv")  # 加载数据集

    test_data = test_data.drop(columns=['TARGET'])  # test set drop columns TARGET
    train_labels = train_data['TARGET']

    # 1. Encoding
    train_data, test_data = LabelEncoding(train_data, test_data)  # label encoding (variables with 2 unique categories)     change
    train_data, test_data = OneHotEncoding(train_data, test_data)  # one-hot encoding

    # 2. 调整训练和测试数据一致
    # The Training and Testing Datasets have the same features which is required for machine learning      change
    train_data, test_data = AligningDate(train_data, test_data, train_labels)  # Aligning Training and Testing Data

    # evaluate model with standardized dataset
    start_time = time.time()
    estimator = KerasClassifier(build_fn=create_baseline, nb_epoch=100, batch_size=5, verbose=0)
    kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
    results = cross_val_score(estimator, train_data, train_labels, cv=kfold) # 如果get_parameters方法报错,查看 https://github.com/fchollet/keras/pull/5121/commits/01c6b7180116d80845a1a6dc1f3e0fe7ef0684d8
    print(results)
    print(results.shape)
    print("Baseline: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))
    end_time = time.time()
    print("用时: ", end_time - start_time)

def LabelEncoding(app_train, app_test):
    print("label encoding:")
    # Create a label encoder object
    le = LabelEncoder()
    le_count = 0

    # Iterate through the columns
    for col in app_train:
        if app_train[col].dtype == 'object':
            # If 2 or fewer unique categories
            if len(list(app_train[col].unique())) <= 2:
                # Train on the training data
                le.fit(app_train[col])
                # Transform both training and testing data
                app_train[col] = le.transform(app_train[col])
                app_test[col] = le.transform(app_test[col])

                # Keep track of how many columns were label encoded
                le_count += 1

    print('%d columns were label encoded.' % le_count)
    print('Training Features shape: ', app_train.shape)
    print('Testing Features shape: ', app_test.shape)
    return app_train, app_test

# one-hot编码
def OneHotEncoding(app_train, app_test):
    print("one-hot encoding:")
    app_train = pd.get_dummies(app_train)
    app_test = pd.get_dummies(app_test)

    print('Training Features shape: ', app_train.shape)
    print('Testing Features shape: ', app_test.shape)
    return app_train, app_test

def AligningDate(app_train, app_test, train_labels):  # Aligning Training and Testing Data
    print('Aliging Date:')
    # train_labels = app_train['TARGET']

    # Align the training and testing data, keep only columns present in both dataframes
    app_train, app_test = app_train.align(app_test, join='inner', axis=1)  # 内连接app_train 和 app_test

    # Add the target back in
    # app_train['TARGET'] = train_labels

    print('Training Features shape: ', app_train.shape)
    print('Testing Features shape: ', app_test.shape)
    return app_train, app_test

# 基准模型
def create_baseline():
    # create model
    model = Sequential()
    model.add(Dense(242, input_dim=242, init='normal', activation='relu'))  # 输入层
    model.add(Dense(1, init='normal', activation='sigmoid'))  # 输出层
    # Compile model
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

if __name__ == '__main__':
    main()
