#!/usr/bin/python
# -*- coding: UTF-8 -*-
import pandas as pd
import operator


def main():
    # 统计各表行列值
    statistic_ColAndLen('../Data/train_data1.csv')
    statistic_ColAndLen('../Data/test_data1.csv')
    # statistic_ColAndLen('../Data/application_train.csv')
    # statistic_ColAndLen('../Data/application_test.csv')
    # statistic_ColAndLen('./First_week/bureau.csv')
    # statistic_ColAndLen('./First_week/bureau_balance.csv')
    # statistic_ColAndLen('./First_week/POS_CASH_balance.csv')
    # statistic_ColAndLen('./First_week/credit_card_balance.csv')
    # statistic_ColAndLen('./First_week/previous_application_del.csv')
    # statistic_ColAndLen('./First_week/previous_application.csv')
    # statistic_ColAndLen('./First_week/installments_payments.csv')

    # statistic_DMRate('./First_week/application_test.csv')
    # statistic_DMRate('./First_week/application_train.csv')
    # aplication_train = pd.read_csv('../Data/application_train_del.csv')  # 读取训练数据
    # df = pd.DataFrame(aplication_train)
    # print(np.unique(df['SK_ID_CURR']))
    # print(df.info())  # 打印df的信息


# 读取数据的行数与列数
def statistic_ColAndLen(position):
    read_data = pd.read_csv(position)  # read original date
    print("%s shape:%s" % (position, read_data.shape))


def statistic_DMRate(name):
    # 特征值缺失率
    print("特征值缺失率:\n")
    Lost = []
    application_train = pd.read_csv(name)  # 读取训练数据
    df = pd.DataFrame(application_train)
    header = df.columns  # 读取行索引
    for col in header:
        Lost.append((col, len(df[col][pd.isnull(df[col])]) / len(df)))  # 计算数据缺失率
        # print("%s:%f"%(col,len(df[col][pd.isnull(df[col])]) / len(df)))
    Lost.sort(key=operator.itemgetter(1), reverse=True) # 对list的第二个关键字进行排序，按降序排序
    for li in Lost:  # 输出list中的元素
        if li[1]>0.5:
           print(li)
    # rd = df['SK_ID_CURR']  # 打印SK_ID_CURR列的数据
    # print(rd)
    # print(len(df["COMMONAREA_MEDI"][pd.isnull(df["COMMONAREA_MEDI"])]) / len(df))
    # print(len(df["COMMONAREA_AVG"][pd.isnull(df["COMMONAREA_AVG"])]) / len(df))
    # print(len(df["COMMONAREA_MODE"][pd.isnull(df["COMMONAREA_MODE"])]) / len(df))
    # print(len(df["NONLIVINGAPARTMENTS_MODE"][pd.isnull(df["NONLIVINGAPARTMENTS_MODE"])]) / len(df))
    # print(len(df["NONLIVINGAPARTMENTS_MEDI"][pd.isnull(df["NONLIVINGAPARTMENTS_MEDI"])]) / len(df))
    # print(df[pd.isnull(df["COMMONAREA_MEDI"])])  # 打印COMMONAREA_MEDI列为null的数据
    # print(df[pd.notnull(df["COMMONAREA_MEDI"])])  # 打印COMMONAREA_MEDI列数据为null的数据


# def FeatureSRate(name):
#     for k, v in word2vec.items():
#         new_dict_list = []
#         s = sorted(v, key=operator.itemgetter("similarity"), reverse=True)
#         word2vec[k] = s
#         for w in word2vec[k]:
#             if w not in new_dict_list:
#                 new_dict_list.append(w)


if __name__ == '__main__':
     main()